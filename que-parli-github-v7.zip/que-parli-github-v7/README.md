# Que parli

**Lo gascon chic a chic** — petite application statique de répétition espacée pour le gascon.

## Structure

```text
index.html
assets/
  app.js
  style.css
data/
  cards.json
pages/
  estudi.html
  cartas.html
  gramatica.html
  sons.html
```

`index.html` ne contient que la coque de l’application. Les quatre onglets sont chargés depuis `pages/`.

## Données

- `data/cards.json` : paquet de référence publié sur GitHub.
- `localStorage` du navigateur : cartes locales et avancement de répétition.
- export `que-parli-changements-AAAA-MM-JJ.json` : seulement les cartes ajoutées ou corrigées depuis le dernier export marqué comme terminé.
- export `cards.json` : paquet complet, prêt à remplacer `data/cards.json` dans le dépôt.
- export `que-parli-avancement-AAAA-MM-JJ.json` : sauvegarde séparée des dates et intervalles SRS.

L’avancement n’est jamais inclus dans le fichier GitHub des cartes.

## Flux téléphone → GitHub

1. Ajouter ou corriger des cartes sur le téléphone.
2. Dans **Cartes**, choisir **Exporter les changements** pour garder un petit fichier de transfert, ou **Exporter cards.json** pour produire directement le paquet complet.
3. Depuis GitHub, ouvrir `data/cards.json`, choisir le remplacement/téléversement du fichier, puis valider le commit.
4. Après publication de GitHub Pages, l’application récupère les nouvelles cartes sans écraser l’avancement local.

Pour transférer un petit export vers un autre appareil, utiliser **Importer / fusionner**, puis **Exporter cards.json** sur cet appareil.

## GitHub Pages

Dans le dépôt : **Settings → Pages → Deploy from a branch**, puis sélectionner la branche principale et le dossier `/ (root)`.

## Test local

Les fragments HTML et `cards.json` sont chargés avec `fetch`, donc l’application ne doit pas être ouverte directement avec `file://`.

```bash
python -m http.server 8000
```

Puis ouvrir `http://localhost:8000`.

## Nouveautés de cette version

- sous-titre **Lo gascon chic a chic** ;
- mémo sur les accents dans l’onglet **Grammaire** ;

- sens de révision français → gascon, gascon → français ou mélangé ;
- onglet **Lexique** avec recherche et filtres ;
- expressions de la fiche de vocabulaire gascon du Gers intégrées comme cartes ;
- petit glossaire culturel régional séparé des cartes linguistiques.

Les expressions provenant de sources extérieures à *A hum de calhau* sont étiquetées explicitement. Le glossaire régional contient aussi des mots français du Sud-Ouest : il ne doit pas être confondu avec un lexique normatif gascon.

## Choix de conception

- Pas de classement par unité de méthode.
- Pas d’audio.
- La dialecte et le dialecte sont facultatifs et surtout utiles quand plusieurs formes coexistent.
- Les statistiques restent locales au navigateur.
- Le code contient des commentaires sur les parties importantes : stockage, import/export, répétition espacée et statistiques.

## Sens de traduction

Dans **Réviser**, le réglage **Langue de départ** permet de choisir :

- français → gascon ;
- gascon → français ;
- aléatoire à chaque nouvelle carte.

Le choix est mémorisé dans le navigateur. En mode aléatoire, le sens ne change pas après avoir révélé la réponse.


## Format des cartes

`data/cards.json` utilise des objets à clés explicites :

```json
{
  "oc": "hemna",
  "fr": "femme",
  "tag": "vocabulaire",
  "dialect": "Bigorre",
  "note": "champ facultatif"
}
```

Seuls `oc` et `fr` sont obligatoires. `tag`, `note` et `dialect` sont facultatifs.
Deux cartes peuvent avoir le même français avec des formes occitanes ou des dialectes différents : elles restent distinctes.


## Carte avec plusieurs dialectes

Une carte regroupe un sens français et toutes ses traductions occitanes :

```json
{
  "fr": "femme",
  "translations": [
    { "oc": "hemna", "dialect": "Bigorre" },
    { "oc": "...", "dialect": "Gers" }
  ],
  "tag": "vocabulaire",
  "note": "champs facultatifs"
}
```

En révision français → occitan, toutes les formes apparaissent au verso. En occitan → français, une forme est choisie au hasard comme question.
